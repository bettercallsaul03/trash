// Функция для проверки числа в поле ввода
function check() {
  let num = document.querySelector(".ti1"); // Получаем элемент с классом "ti1" (поле ввода)
  let label = document.querySelector(".tl1"); // Получаем элемент с классом "tl1" (для отображения результата)
  if (num.value > 0) { // Если значение в поле больше 0
    console.log(1); // Выводим в консоль число 1
    label.innerHTML = num.value * num.value; // Показываем квадрат числа в элементе "tl1"
  }
  if (num.value < 0) { // Если значение в поле меньше 0
    console.log(num.value * num.value); // Выводим в консоль квадрат числа
  } else { // Если значение не больше и не меньше 0 (значит, равно 0)
    alert(num.value * num.value); // Показываем квадрат числа в всплывающем окне
  }
}

// Функция для работы с изображениями
function img() {
  let arrImg = new Array(
    "1.jpg",
    "2.jpg",
    "3.jpg",
    "4.jpg",
    "5.jpg",
    "6.jpg",); // Массив ссылок на изображения
  let num = document.querySelector(".ti2"); // Получаем элемент с классом "ti2" (поле ввода)
  let img = document.querySelector("img"); // Получаем элемент <img>
  if (num.value > 7 || num.value < 1) { 
    alert("Введите от 1 до 6"); 
  } else { 
    img.src = arrImg[num.value - 1]; 
  }
}

// Функция для генерации случайного числа в заданном диапазоне
function getRandomInt(min, max) {  
  return Math.floor(Math.random() * (max - min + 1)) + min; // Возвращаем случайное число от min до max
}

// Функция для создания блока с рандомными размерами и цветом
function createRandomBlock() {  
  const block = document.querySelector('.t3'); // Получаем элемент с классом "t3"

  const width = getRandomInt(100, 500); // Случайная ширина 
  const height = getRandomInt(100, 500); // Случайная высота 
  block.style.width = `${width}px`; // Устанавливаем ширину блока
  block.style.height = `${height}px`; // Устанавливаем высоту 

  const r = getRandomInt(0, 255); 
  const g = getRandomInt(0, 255); 
  const b = getRandomInt(0, 255); 
  block.style.backgroundColor = `rgb(${r}, ${g}, ${b})`; // Устанавливаем случайный цвет фона блока

  const area = width * height; 
  block.innerHTML = `Площадь: ${area}`; // Отображаем площадь внутри блока
}
createRandomBlock(); // Вызываем функцию создания блока

//угадай число
const randomNumber = getRandomInt(0, 100); 
let attempts = 0; // кол-во траев
let userGuess; // для хранения числа пользователя
while (userGuess !== randomNumber) {  
    userGuess = prompt("Введите ваше число от 0 до 100:"); // Спрашиваем число у пользователя
    userGuess = Number(userGuess); // Преобразуем введенное значение в число
    attempts += 1; // прибавляем кол-во траев
    if (isNaN(userGuess) || userGuess < 0 || userGuess > 100) { // проверка диапазона
        alert("Пожалуйста, введите число от 0 до 100.");
        continue; 
    }
    const guessesDiv = document.getElementById("guesses"); // Находим контейнер для отображения попыток
    const guessDiv = document.createElement("div"); // Создаем новый div для текущей попытки
    guessDiv.className = "guess"; // Устанавливаем класс для нового div
    guessDiv.textContent = `Попытка ${attempts}: ${userGuess}`; // Добавляем текст с информацией о попытке
    guessesDiv.appendChild(guessDiv); // Добавляем новый div в контейнер
    if (userGuess > randomNumber) { // Если число больше загаданного
        alert("Меньше! Попробуйте еще раз."); // Подсказываем пользователю
    } else if (userGuess < randomNumber) { // Если число меньше загаданного
        alert("Больше! Попробуйте еще раз."); // Подсказываем пользователю
    } else { // Если число угадано
        alert(`Поздравляем! Вы угадали число ${randomNumber} за ${attempts} попыток.`); // Сообщаем о победе
        document.getElementById("result").textContent = `Вы угадали число ${randomNumber} за ${attempts} попыток.`; // Показываем результат
    }
}

// Случайная ссылка
let link = document.querySelector("a"); // Находим элемент <a>
let arrHref = new Array(
  "w1/index.html",
  "w2/index.html",
  "w3/index.html",
  "w4/index.html",
  "w5/index.html"
); // Массив ссылок
link.href = arrHref[getRandomInt(0, 4)]; // Устанавливаем случайную ссылку из массива
