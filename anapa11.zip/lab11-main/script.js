// **1. Меняющийся цвет элементов**
// Массив с цветами, которые будут использоваться для смены фона
const colors = ["#FFAAAA", "#FFCCAA", "#FFE4AA", "#AAFFD4", "#AAAFFF"];

// Получаем все элементы div с классом "color-box"
const colorBoxes = document.querySelectorAll(".color-box");

// Переменная для отслеживания текущего индекса цвета
let colorIndex = 0;

// Устанавливаем интервал, который обновляет цвета каждые 1000 мс (1 секунда)
setInterval(() => {
  // Проходим по каждому div и задаем ему новый цвет из массива
  colorBoxes.forEach((box, i) => {
    box.style.backgroundColor = colors[(colorIndex + i) % colors.length];
    // Индекс цвета вычисляется по модулю длины массива, чтобы возвращаться к началу
  });
  // Увеличиваем индекс для следующей итерации
  colorIndex++;
}, 1000);

// **2. Двигающийся круг**
// Получаем элемент div, который будет двигаться
const circle = document.getElementById("moving-circle");

// Функция для перемещения круга в случайные координаты
function moveCircle() {
  // Случайная координата X (в пределах ширины окна)
  const x = Math.random() * (window.innerWidth - 50);
  // Случайная координата Y (в пределах высоты окна)
  const y = Math.random() * (window.innerHeight - 50);

  // Перемещаем круг с помощью CSS-свойства transform
  circle.style.transform = `translate(${x}px, ${y}px)`;
  
  // Вызываем функцию снова через 3 секунды
  setTimeout(moveCircle, 3000);
}
// Запускаем функцию перемещения круга
moveCircle();

// **3. Генерация HTML-списка**
// Добавляем обработчик события на кнопку "Generate List"
document.getElementById("generate-list").addEventListener("click", () => {
  const data = []; // Массив для хранения введенных пользователем данных
  let input;

  // Цикл для получения данных от пользователя через prompt
  do {
    input = prompt("Введите элемент списка (пустая строка для завершения):");
    if (input) data.push(input); // Если строка не пустая, добавляем в массив
  } while (input);

  // Создаем элемент списка (ul)
  const ul = document.createElement("ul");
  
  // Проходим по массиву данных и создаем элементы списка (li)
  data.forEach(item => {
    const li = document.createElement("li"); // Создаем элемент li
    li.textContent = item; // Устанавливаем текст li
    ul.appendChild(li); // Добавляем li в ul
  });

  // Добавляем созданный список в тело страницы
  document.body.appendChild(ul);
});

// **4. Генерация постов**
// Добавляем обработчик события на кнопку "Generate Posts"
document.getElementById("generate-posts").addEventListener("click", () => {
  // Массив ссылок на картинки
  const images = [
    "catet.jpg"
    // "https://via.placeholder.com/150/FFAAAA",
    // "https://via.placeholder.com/150/FFCCAA",
    // "https://via.placeholder.com/150/FFE4AA",
    // "https://via.placeholder.com/150/AAFFD4",
    // "https://via.placeholder.com/150/AAAFFF",
  ];

  // Массив предложений для случайного текста
  const sentences = [
    "ГОООООООООООООЛ.",
    "БААЗААААА.",
    "УРАААААААААА.",
    "ПРООООГРЕЕЕЕЕВ.",
    "ПРОГРЕЕЕЕВ ГОООЕВ!",
  ];

  // Получаем количество постов и предложений от пользователя через prompt
  const postCount = parseInt(prompt("Введите количество постов:"));
  const sentenceCount = parseInt(prompt("Введите количество предложений в посте:"));

  // Создаем контейнер для постов
  const postsContainer = document.createElement("div");
  postsContainer.id = "posts";

  // Генерируем посты
  for (let i = 0; i < postCount; i++) {
    const post = document.createElement("div"); // Создаем div для поста
    post.className = "post"; // Присваиваем ему класс "post"

    // Добавляем картинку в пост
    const img = document.createElement("img");
    img.src = images[Math.floor(Math.random() * images.length)]; // Случайная картинка из массива
    img.style.width = "100%"; // Устанавливаем ширину картинки
    post.appendChild(img); // Добавляем картинку в пост

    // Добавляем текст в пост
    const p = document.createElement("p");
    for (let j = 0; j < sentenceCount; j++) {
      const sentence = sentences[Math.floor(Math.random() * sentences.length)];
      p.textContent += sentence + " "; // Добавляем случайное предложение
    }
    post.appendChild(p); // Добавляем текст в пост

    // Устанавливаем случайный цвет текста и фона
    post.style.color = `#${Math.floor(Math.random() * 16777215).toString(16)}`;
    post.style.backgroundColor = `#${Math.floor(Math.random() * 16777215).toString(16)}`;

    // Добавляем пост в контейнер
    postsContainer.appendChild(post);
  }

  // Добавляем контейнер с постами в тело страницы
  document.body.appendChild(postsContainer);
});
