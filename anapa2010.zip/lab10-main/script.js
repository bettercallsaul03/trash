// ======== Массив сотрудников ======== //
const employees = [];

// Добавление сотрудника
document.getElementById("add-employee").addEventListener("click", () => {
    const lastName = prompt("Введите фамилию сотрудника:");
    const firstName = prompt("Введите имя сотрудника:");
    const middleName = prompt("Введите отчество сотрудника:");
    const birthYear = prompt("Введите год рождения сотрудника:");
    const position = prompt("Введите должность сотрудника:");

    // Проверяем, чтобы все поля были заполнены
    if (lastName && firstName && middleName && birthYear && position) {
        employees.push({ lastName, firstName, middleName, birthYear, position });
        updateEmployeeTable();
    } else {
        alert("Все поля должны быть заполнены!");
    }
});

// ======== Обновление таблицы сотрудников ======== //
function updateEmployeeTable() {
    const table = document.getElementById("data-table");

    // Проверяем, есть ли уже заголовок таблицы, и создаем его при необходимости
    if (employees.length === 1) {
        table.innerHTML = `
            <thead>
                <tr>
                    <th>Фамилия</th>
                    <th>Имя</th>
                    <th>Отчество</th>
                    <th>Год рождения</th>
                    <th>Должность</th>
                </tr>
            </thead>
            <tbody></tbody>
        `;
    }

    // Находим `tbody` таблицы и добавляем в него нового сотрудника
    const tbody = table.querySelector("tbody");
    const newRow = document.createElement("tr");

    const lastEmployee = employees[employees.length - 1];
    newRow.innerHTML = `
        <td>${lastEmployee.lastName}</td>
        <td>${lastEmployee.firstName}</td>
        <td>${lastEmployee.middleName}</td>
        <td>${lastEmployee.birthYear}</td>
        <td>${lastEmployee.position}</td>
    `;

    tbody.appendChild(newRow);
}

// ======== Массив гиперссылок ======== //
const links = [
    { href: "page1.html", text: "Перейти на страницу 1", tooltip: "Страница 1", className: "link-style-1" },
    { href: "page2.html", text: "Перейти на страницу 2", tooltip: "Страница 2", className: "link-style-2" },
    { href: "page3.html", text: "Перейти на страницу 3", tooltip: "Страница 3", className: "link-style-3" },
];

// Функция для генерации HTML-кода ссылки
function generateLinkHtml(link) {
    return `<a href="${link.href}" class="${link.className}" title="${link.tooltip}">${link.text}</a>`;
}

// Отображение случайной ссылки
function displayRandomLink() {
    const randomLink = links[Math.floor(Math.random() * links.length)];
    document.getElementById("random-link").innerHTML = generateLinkHtml(randomLink);
}

// Вызываем функцию при загрузке страницы
displayRandomLink();
